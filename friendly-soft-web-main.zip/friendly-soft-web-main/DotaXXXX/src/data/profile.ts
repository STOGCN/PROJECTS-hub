export const PROFILE = {
  name: "Ratchanon Katsakoon",
  role: "Project Manager",
  tagline: "Passionate Leader • Always Learning",
  location: "Chiang Mai, Thailand",
  email: "ratchanon_kat@cmu.ac.th",
  socials: {
    github: "https://github.com/DotaXXXX",
    instagram: "https://www.instagram.com/_ratchanonn_rk/",
  },
};
