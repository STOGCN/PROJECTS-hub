export const EXPERIENCE = [
  {
    role: "Student Developer (Intern)",
    org: "University Project ",
    period: "Jun 2024 – Sep 2024",
    bullets: [
      "Learned web development with React and TypeScript",
      "Worked on group project for student data management system",
    ],
  },
  {
    role: "Freelance Web Developer",
    org: "Part-time Projects",
    period: "2023 – Present",
    bullets: [
      "Built small websites for local shops and businesses",
      "Learned HTML, CSS, JavaScript and Bootstrap",
    ],
  },
];
