export const STACK = [
  { name: "TypeScript", level: 5 },
  { name: "React", level: 5 },
  { name: "Node.js", level: 4 },
  { name: "Tailwind CSS", level: 5 },
  { name: "PostgreSQL", level: 4 },
  { name: "Docker", level: 3 },
];
